package es.dam.streamingcatalog;

import es.dam.streamingcatalog.model.Critica;
import es.dam.streamingcatalog.model.Estudio;
import es.dam.streamingcatalog.model.Pelicula;
import es.dam.streamingcatalog.repository.CriticaRepo;
import es.dam.streamingcatalog.repository.EstudioRepo;
import es.dam.streamingcatalog.repository.PeliculaRepo;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.util.List;

public class Main {

    public static void main(String[] args) {

        // Crear el EntityManagerFactory usando el persistence-unit del persistence.xml
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("catalogPU");
        EntityManager em = emf.createEntityManager();

        // Crear repositorios
        EstudioRepo estudioRepo = new EstudioRepo(em);
        PeliculaRepo peliculaRepo = new PeliculaRepo(em);
        CriticaRepo criticaRepo = new CriticaRepo(em);

        try {
            System.out.println(" PARTE 1: Crear Estudio y Películas ");

            em.getTransaction().begin();

            // crear un Estudio
            Estudio estudio = new Estudio("Studios", 2005);

            // crear dos Peliculas asociadas al Estudio
            Pelicula pelicula1 = new Pelicula("pelicula 1", 2018, "Amor");
            Pelicula pelicula2 = new Pelicula("pelicula 2", 2022, "Terror");

            // asociar peliculas al estudio
            estudio.addPelicula(pelicula1);
            estudio.addPelicula(pelicula2);

            // Crear algunas críticas para una de las peliculas
            Critica critica1 = new Critica("Jorge", 9, "Muy buena peli");
            Critica critica2 = new Critica("Lucia", 8, "Buen ritmo");

            pelicula1.addCritica(critica1);
            pelicula1.addCritica(critica2);

            // Guardar solo el estudio: gracias al cascade, se guardan Peliculas y Criticas
            estudioRepo.guardar(estudio);

            em.getTransaction().commit();

            System.out.println("Estudio guardado con ID: " + estudio.getId());
            System.out.println("Pelicula 1 ID: " + pelicula1.getId());
            System.out.println("Pelicula 2 ID: " + pelicula2.getId());

            System.out.println(" PARTE 2: Actualizar año de una Pelicula");

            em.getTransaction().begin();

            // Recuperamos la pelicula por id (ejemplo: pelicula1)
            Pelicula peliParaActualizar = peliculaRepo.buscarID(pelicula1.getId());
            System.out.println("Antes de actualizar: " + peliParaActualizar);

            // Actualizar el año de una Pelicula
            peliParaActualizar.setAnioLanzamiento(2020);
            peliculaRepo.update(peliParaActualizar);

            em.getTransaction().commit();

            System.out.println("Despues de actualizar: " + peliculaRepo.buscarID(pelicula1.getId()));

            System.out.println("PARTE 3: Buscar peliculas posteriores a un año ");

            int anioBusqueda = 2019;
            List<Pelicula> peliculasPosteriores = peliculaRepo.findByAnioMayorQue(anioBusqueda);

            System.out.println("peliculas con año de lanzamiento mayor que " + anioBusqueda + ":");
            for (Pelicula p : peliculasPosteriores) {
                System.out.println(p);
            }

            System.out.println("PARTE 4: Eliminar Estudio ");

            em.getTransaction().begin();

            // Volvemos a cargar el estudio desde BD por si acaso
            Estudio estudioParaBorrar = estudioRepo.buscarId(estudio.getId());
            System.out.println("Eliminando estudio: " + estudioParaBorrar);

            // Eliminar el Estudio
            estudioRepo.delete(estudioParaBorrar);

            em.getTransaction().commit();

            System.out.println("Estudio eliminado.");
            System.out.println("Revisa en la consola SQL como se eliminan tambien Peliculas y Criticas.");

        } catch (Exception e) {
            e.printStackTrace();
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
        } finally {
            em.close();
            emf.close();
        }
    }
}
