package es.dam.streamingcatalog.repository;

import es.dam.streamingcatalog.model.Critica;
import jakarta.persistence.EntityManager;

import java.util.List;

public class CriticaRepo {

    private EntityManager em;

    public CriticaRepo(EntityManager em) {
        this.em = em;
    }

    public void guardar(Critica critica) {
        em.persist(critica);
    }

    public Critica buscarId(Long id) {
        return em.find(Critica.class, id);
    }

    public List<Critica> leerTodo() {
        return em.createQuery("SELECT c FROM Critica c", Critica.class)
                .getResultList();
    }

    public Critica update(Critica critica) {
        return em.merge(critica);
    }

    public void delete(Critica critica) {
        if (!em.contains(critica)) {
            critica = em.merge(critica);
        }
        em.remove(critica);
    }
}
