package es.dam.streamingcatalog.repository;

import es.dam.streamingcatalog.model.Estudio;
import jakarta.persistence.EntityManager;

import java.util.List;

public class EstudioRepo {

    private EntityManager em;

    public EstudioRepo(EntityManager em) {
        this.em = em;
    }

    // CREATE
    public void guardar(Estudio estudio) {
        em.persist(estudio);
    }

    // READ por id
    public Estudio buscarId(Long id) {
        return em.find(Estudio.class, id);
    }

    // READ todos
    public List<Estudio> leerTodo() {
        return em.createQuery("SELECT e FROM Estudio e", Estudio.class)
                 .getResultList();
    }

    // UPDATE
    public Estudio update(Estudio estudio) {
        return em.merge(estudio);
    }

    // DELETE
    public void delete(Estudio estudio) {
        if (!em.contains(estudio)) {
            estudio = em.merge(estudio); 
        }
        em.remove(estudio);
    }
}
