package es.dam.streamingcatalog.repository;

import es.dam.streamingcatalog.model.Pelicula;
import jakarta.persistence.EntityManager;

import java.util.List;

public class PeliculaRepo {

    private EntityManager em;

    public PeliculaRepo(EntityManager em) {
        this.em = em;
    }

    // CREATE
    public void guardar(Pelicula pelicula) {
        em.persist(pelicula);
    }

    // READ por id
    public Pelicula buscarID(Long id) {
        return em.find(Pelicula.class, id);
    }

    // READ todos
    public List<Pelicula> leerTodo() {
        return em.createQuery("SELECT p FROM Pelicula p", Pelicula.class)
                .getResultList();
    }

    // UPDATE
    public Pelicula update(Pelicula pelicula) {
        return em.merge(pelicula);
    }

    // DELETE
    public void delete(Pelicula pelicula) {
        if (!em.contains(pelicula)) {
            pelicula = em.merge(pelicula);
        }
        em.remove(pelicula);
    }

    // Consulta avanzada de peliculas con año de lanzamiento > anio
    public List<Pelicula> findByAnioMayorQue(int anio) {
        String jpql = "SELECT p FROM Pelicula p WHERE p.anioLanzamiento > :anio";
        return em.createQuery(jpql, Pelicula.class)
                .setParameter("anio", anio)
                .getResultList();
    }
}
